// import logo from './logo.svg';
import './App.css';
import Task1 from './Task1';

function App() {
  return (
    <div>
      <Task1/>
    </div>
  );
}

export default App;
